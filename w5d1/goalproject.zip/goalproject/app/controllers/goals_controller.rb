class GoalsController < ApplicationController
  def index
    @goals = current_user.goals
  end

  def new
    @goal = Goal.new
  end

  def create
    @goal = Goal.new(goals_params)
    @goal.user_id = current_user.id
    if @goal.save
      redirect_to @goal
    else
      flash[:errors] = @goal.errros.full_messages
      render :new
    end
  end

  def show
    @goal = Goal.find(params[:id])
  end

  def edit
    @goal = Goal.find(params[:id])
  end

  def update
    @goal = current_user.goals.find_by_id(params[:id])
    if @goal.nil?
      flash[:errors] = ["You can't edit that goal!"]
      redirect_to goal_url(params[:id])
    elsif @goal.update(goals_params)
      redirect_to goals_url
    else
      flash[:errors] = @goal.errors.full_messages
      render :edit
    end
  end

  def destroy
    @goal = Goal.find_by_id(params[:id])
    @goal.destroy
    redirect_to goals_url
  end

  def goals_params
    params.require(:goal).permit(:title, :private, :details, :completed)
  end
end
