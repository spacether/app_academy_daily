# == Schema Information
#
# Table name: users
#
#  id              :integer          not null, primary key
#  username        :string
#  password_digest :string
#  session_token   :string
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#

require 'rails_helper'

RSpec.describe User, type: :model do

  describe "validations" do
    it { should validate_presence_of(:username) }
    it { should validate_uniqueness_of(:username) }
  end

  describe "relations" do
    it { should have_many(:goals) }
    it { should have_many(:comments) }
  end

  describe "Password checking" do

    it "password is not saved to database" do
      expect(User).to_not respond_to(:password)
    end

    it "returns the correct user give valid credentials" do
      user = User.create(username: "Dallas", password: "test123")
      expect(User.find_by_credentials("Dallas", "test123")).to eq(user)
    end

  end

end
