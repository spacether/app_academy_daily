require 'spec_helper'
require 'rails_helper'

feature "the signup process" do

  scenario "has a new user page" do
    visit new_user_url
    expect(page).to have_content "New User"
  end

  feature "signing up a user" do

    scenario "shows username on the homepage after signup" do
      visit new_user_url
      fill_in 'Username', with: "TestUsername"
      fill_in 'Password', with: "test1234"
      click_on "Create User"
      expect(page).to have_content "TestUsername"
    end
  end

end

feature "logging in" do

  scenario "shows username on the homepage after login" do
    visit new_user_url
    fill_in 'Username', with: "TestUsername"
    fill_in 'Password', with: "test1234"
    click_on "Create User"
    click_on "Log Out"
    visit new_session_url
    fill_in 'Username', with: "TestUsername"
    fill_in 'Password', with: "test1234"
    click_on "Log In"
    # save_and_open_page

    expect(page).to have_content "TestUsername"
  end

end

feature "logging out" do
  before(:each) do
    visit new_user_url
    fill_in 'Username', with: "TestUsername"
    fill_in 'Password', with: "test1234"
    click_on "Create User"
    click_on "Log Out"
  end

  scenario "begins with a logged out state" do
    expect(page).to have_content "Log In"
  end

  scenario "doesn't show username on the homepage after logout" do
    expect(page).to_not have_content "TestUsername"
  end

end
