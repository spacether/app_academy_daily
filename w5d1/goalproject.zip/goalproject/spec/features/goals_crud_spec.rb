require 'spec_helper'
require 'rails_helper'

feature "goals CRUD" do

  feature "when not logged in" do
    it "kicks out the user to the sign in page" do
      visit new_user_url
      fill_in "Username", with: "Justin"
      fill_in "Password", with: "justin"
      click_button "Create User"
      click_button "Log Out"
      expect(page).to have_content "Log In"
    end
  end

  feature "when logged in" do
    before(:each) do
      visit new_user_url
      fill_in "Username", with: "Justin"
      fill_in "Password", with: "justin"
      click_button "Create User"
      click_button "Log Out"
      fill_in "Username", with: "Justin"
      fill_in "Password", with: "justin"
      click_button "Log In"
    end

    it "can create goals for self" do
      make_goal("Read the Three Body Problem", true, "a book")
      expect(page).to have_content("Read the Three Body Problem")
    end

    it "can't edit other's goals" do
      make_goal("Read the Three Body Problem", true, "a book")
      click_button "Log Out"
      visit new_user_url
      fill_in "Username", with: "Sam"
      fill_in "Password", with: "password"
      click_button "Create User"
      visit edit_goal_url(Goal.first)
      click_button "Update Goal"
      expect(page).to have_content("You can't edit that goal!")
    end


    it "can delete one's goals" do
      make_goal("Read the Three Body Problem", true, "a book")
      click_on "Delete Goal"
      expect(page).to_not have_content("Read the Three Body Problem")
    end


    it "can edit one's goals" do
      make_goal("Read the Three Body Problem", true, "a book")
      click_on "Edit Goal"
      fill_in "Title", with: "I am a title"
      click_on "Update Goal"
      expect(page).to_not have_content("Read the Three Body Problem")
      expect(page).to have_content("I am a title")
    end

  end
end
