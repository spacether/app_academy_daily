class UsersController < ApplicationController

  def new
    render :new
  end

  def create
    user = User.new(user_name: params[:user][:user_name])
    user.password = params[:user][:password]

    if user.save
      redirect_to cats_url
    else
      flash.now[:errors] = ["User name is taken"]
      render :new
    end
  end
end
