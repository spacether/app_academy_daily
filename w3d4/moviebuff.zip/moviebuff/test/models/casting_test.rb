require 'test_helper'

class CastingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
