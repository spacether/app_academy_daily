module CatRentalsHelper
end
