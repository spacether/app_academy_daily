# == Schema Information
#
# Table name: cat_rental_requests
#
#  id         :integer          not null, primary key
#  created_at :datetime
#  updated_at :datetime
#  cat_id     :integer          not null
#  start_date :date             not null
#  end_date   :date             not null
#  status     :text             default("PENDING"), not null
#

class CatRentalRequest < ActiveRecord::Base
  validates :cat_id, :start_date, :end_date, :status, presence: true
  validate :overlapping_approved_requests, on: :update

  def overlapping_requests
    vals1 = [self.start_date, self.end_date, self.cat_id]
    inside_self = CatRentalRequest.where("start_date > ? AND end_date < ? AND cat_id = ?", *vals1)

    vals2 = [self.start_date, self.start_date, self.cat_id]
    intersects_start = CatRentalRequest.where("end_date > ? AND start_date < ? AND cat_id = ?", *vals2)

    vals3 = [self.end_date, self.end_date, self.cat_id]
    intersects_end = CatRentalRequest.where("start_date < ? AND end_date > ? AND cat_id = ?", *vals3)

    inside_self + intersects_end + intersects_start
  end

  def approve!
    self.status = "APPROVED"
    unless self.save
      self.status = "DENIED"
      self.save
    end
  end

  def overlapping_approved_requests
    bool = overlapping_requests.none? { |r| r.status == "APPROVED" }
    unless bool
      errors.add :start_date, "possibly intersects with an existing approved rental"
      errors.add :end_date, "possibly intersects with an existing approved rental"
    end
  end

  belongs_to :cat

end
