# == Schema Information
#
# Table name: cats
#
#  id          :integer          not null, primary key
#  birth_date  :date             not null
#  color       :string           not null
#  name        :string           not null
#  sex         :string(1)        not null
#  description :text             not null
#  created_at  :datetime
#  updated_at  :datetime
#

class Cat < ActiveRecord::Base
  def self.COLORS
    %w(brown white calico tuxedo)
  end

  validates :birth_date, :color, :name, :sex, :description, presence: true
  validates_inclusion_of :sex, in: %w(M F)
  validates_inclusion_of :color, in: Cat.COLORS

  has_many :cat_rental_requests,
    dependent: :destroy

end
