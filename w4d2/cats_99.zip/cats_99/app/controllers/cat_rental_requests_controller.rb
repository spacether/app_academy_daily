class CatRentalRequestsController < ApplicationController

  def index
    @cat = Cat.find(params[:cat_id])
    @rentals = CatRentalRequest.where(cat_id: params[:cat_id]).order(start_date: :desc)
    render :index
  end

  def new
  end

  def create
    @rental = CatRentalRequest.new(cat_rental_req_params)
    @cat = Cat.find(cat_rental_req_params[:cat_id])
    if @rental.save
      redirect_to cat_cat_rental_requests_url(@cat)
    else
      render(
      json: @rental.errors.full_messages,
      status: :unprocesable_entity
      )
    end
  end

  private
  def cat_rental_req_params
    params.require(:cat_rental_request).permit(:cat_id, :start_date, :end_date)
  end
end
