# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)


Cat.destroy_all
c1 = Cat.create!(birth_date: "2005-12-01", color: Cat.COLORS.sample, name: 'Harry', sex: 'F', description: "I'm a cat")
c2 = Cat.create!(birth_date: "2007-12-01", color: Cat.COLORS.sample, name: 'Sam', sex: 'M', description: "I'm a cat")
c3 = Cat.create!(birth_date: "2001-12-01", color: Cat.COLORS.sample, name: 'Cherry', sex: 'F', description: "I'm a cat")
c4 = Cat.create!(birth_date: "2009-12-01", color: Cat.COLORS.sample, name: 'Pookums', sex: 'F', description: "I'm a cat")
c5 = Cat.create!(birth_date: "2010-12-01", color: Cat.COLORS.sample, name: 'Ignats', sex: 'M', description: "I'm a cat")

CatRentalRequest.destroy_all
r1 = CatRentalRequest.create!(cat_id: c1.id, start_date: 5.days.ago, end_date: 1.day.ago, status: "APPROVED")
r2 = CatRentalRequest.create!(cat_id: c1.id, start_date: 10.days.ago, end_date: 8.day.ago)
r3 = CatRentalRequest.create!(cat_id: c2.id, start_date: 5.days.ago, end_date: 1.day.ago)
r4 = CatRentalRequest.create!(cat_id: c1.id, start_date: 4.days.ago, end_date: 2.day.ago)
r5 = CatRentalRequest.create!(cat_id: c1.id, start_date: 8.days.ago, end_date: 4.day.ago)
r6 = CatRentalRequest.create!(cat_id: c1.id, start_date: 4.days.ago, end_date: Time.now)
